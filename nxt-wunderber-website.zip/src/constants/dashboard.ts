export const DASHBOARD_LINKS:{label:string, href:string, Icon?:any|string}[] =[
    
    {label:'Dashboard',href:"/dashboard"},
    {label:'Orders',href:"/dashboard/orders"},
    {label:'Guests',href:"/dashboard/guests"},
    {label:'Employees',href:"/dashboard/employees"},
    {label:'Settings',href:"/dashboard/settings"},
    {label:'Home',href:"/"},
   
   
]