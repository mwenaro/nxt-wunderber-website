export {default as TouristAttractionList} from './TouristAttractionList'

