import React from 'react'

export default function Settings() {
  return (
    <div>Settings</div>
  )
}
