import React from 'react'

export default function Employees() {
  return (
    <div>Employees</div>
  )
}
