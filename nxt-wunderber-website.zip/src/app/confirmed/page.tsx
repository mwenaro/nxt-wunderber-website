

export default function page() {
  return (
    <div>You are confired!</div>
  )
}
