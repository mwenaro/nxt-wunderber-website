"use client"
import { BookingForm, PageWrapper } from "@/components/modules";



export default function Booking() {
  return (
    <PageWrapper>
      <BookingForm />
    </PageWrapper>
  )
}
